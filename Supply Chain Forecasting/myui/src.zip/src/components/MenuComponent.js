import React from 'react';

const MenuComponent = () => (
   <nav className="navbar">
    Supply Chain Forecasting Dashboard
  </nav>
);

export default MenuComponent;